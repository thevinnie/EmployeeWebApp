use WideWorldImportersDW
GO

select c.City, c.[State Province] as StateProvince, c.Country, sum(s.Profit) TotalProfit
from Dimension.City c
join Fact.Sale s ON c.[City Key] = s.[City Key]
group by c.City, c.[State Province] , c.Country