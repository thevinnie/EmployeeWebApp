drop table if exists Integration.ETLAudit
go

create table Integration.ETLAudit
(ETLAuditID INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_ETLAuditID PRIMARY KEY CLUSTERED (ETLAuditID)
, PackageName NVARCHAR(250)
, TimeStart DATETIME2(4)
, TimeEnd DATETIME2(4)
, ExecutionAccount NVARCHAR(256) DEFAULT SUSER_NAME()
)
go

INSERT INTO Integration.ETLAudit (PackageName, TimeStart)
SELECT 'NewPackage', GETDATE()
go

SELECT * FROM Integration.ETLAudit